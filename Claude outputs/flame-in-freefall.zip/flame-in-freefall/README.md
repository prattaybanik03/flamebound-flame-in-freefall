# Flame in Freefall: NASA Space Apps 2026 (Melbourne)

Challenge: [Flame in Freefall: SI-Powered Fire Safety Insights from Microgravity Combustion Data](https://www.spaceappschallenge.org/2026/challenges/flame-in-freefall/)

## Data

All data comes from NASA's [Physical Sciences Informatics (PSI)](https://psi.nasa.gov/physci/repo/search?q=combustion) repository. Records are licensed CC0-1.0. Cite each investigation by its DOI, as PSI requests.

```bash
pip install -r requirements.txt
python scripts/fetch_psi.py
```

This fetches 23 combustion investigations through the public PSI API. They cover ACME (Flame Design, BRE, CLD, E-FIELD, s-Flame, CFI-G), BASS, BASS-II, CFI, FLEX, FLEX-2, Saffire I-III, SAME, SAME-R, SLICE, SPICE and several analysis studies. Each experimental table comes with it.

| Output | What it is |
| --- | --- |
| `data/investigations.json` | One cleaned record per investigation: objective, hypothesis, approach, research impacts, hardware, dates, DOI, publications |
| `data/tests.csv` | Every experimental-table cell in long form, tagged with investigation ID and DOI |
| `data/tests_normalized.csv` | One row per test, with oxygen, pressure, flow, material or fuel, and burn time extracted. Each value keeps its original column name. |
| `data/raw/` | Untouched API responses and CSVs, for traceability |

The extracted values are kept as raw strings. Units and formats differ between investigations (for example "Percent O2 = 21.5" vs "XO2 = 0.21"), so convert units deliberately, never silently.

## Use of SI (to declare on the project page)

- The PSI data fetcher (`scripts/fetch_psi.py`) was written with help from Claude (Anthropic), an SI assistant.
- The solution concept is the team's own.
