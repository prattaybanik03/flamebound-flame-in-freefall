# PyroVector build plan

The execution plan for every coding agent, written for cheaper or faster models. Do **one task per session**, in order. Each task lists its files, its "done when" checks, and its guardrails. Times are AEDT.

**Before any task:** read `AGENTS.md`, `agents/RULES.md` and `agents/DECISIONS.md`. Also read `web/AGENTS.md`: this is Next.js 16, which differs from your training data, so check `web/node_modules/next/dist/docs/` before using an API you're unsure of.

**After every task:**
- Run `cd web && npm test && npm run build`. Both must pass.
- Tick the task in this file and update `agents/STATUS.md`.
- Add a line to `agents/SI_LOG.md`.
- Commit with a short imperative message and **no AI attribution**.

## Already done (don't redo)

| Piece | Where | State |
| --- | --- | --- |
| PSI fetch → conditions → app bundle | `scripts/fetch_psi.py`, `build_conditions.py`, `build_app_data.py` → `web/public/data/pyrovector.json` | Done |
| BCMS engine (locked spec) | `web/src/lib/bcms.ts` | Done, 13 tests |
| Cited verdict logic | `web/src/lib/verdict.ts` | Done, tested |
| Types | `web/src/lib/types.ts` | Done |
| Presets and material list | `web/src/lib/presets.ts` | Done (type-checks; not yet used by the UI) |
| "Why #1 beats #2" sentence + numeric firewall | `web/src/lib/explain.ts` | Done (type-checks; no tests yet) |
| Regime map component | `web/src/components/RegimeMap.tsx` | Drafted, type-checks, **never rendered**. Verify in A6 |

**Don't change the scoring semantics in `bcms.ts` or `verdict.ts`.** That includes weights, scales, the missing-equals-zero rule, envelope exclusion, the pillar-scoped threshold and the cited-only verdict. They're Pratt's locked decisions. Constants marked PROVISIONAL change only when Pratt says so.

---

## Phase A: thin slice (gate: Sat 22:00, one scenario working end to end, live URL)

### A1. App shell and data loading
- Files: `web/src/app/layout.tsx`, `web/src/app/page.tsx`, `web/src/app/globals.css`, new `web/src/components/PyroVector.tsx` (`"use client"`)
- `page.tsx` renders `<PyroVector />` and nothing else. Remove the create-next-app boilerplate.
- Metadata: title "PyroVector: NASA microgravity fire-safety envelopes", plus a description built from the tagline in DECISIONS.md.
- Dark theme (slate-950 background), system font stack. If `next/font/google` breaks the build, remove it.
- `PyroVector` fetches `/data/pyrovector.json` once on mount and keeps it in state. Show a loading state, and an error state with a retry button.
- **Done when:** the page loads, shows "PyroVector", and logs the number of investigations (23) and records (1,980) in dev.

### A2. Controls panel
- File: new `web/src/components/Controls.tsx`. Target state lives in `PyroVector`, starting from `DEFAULT_TARGET`.
- Pillar tabs: Flammability and Suppression. Detection is shown disabled, with the tooltip "Coming: SAME / SAME-R smoke data".
- Preset buttons from `PRESETS`. Clicking one sets the O2 and pressure (`psiaToKpa`). Show each preset's `source` as small text or a tooltip.
- Sliders, each with its numeric value visible:
  - O2 % (10–100, step 0.5)
  - Pressure in kPa (20–320, step 0.5), with the psia value shown alongside (`kpaToPsia`)
  - Airflow in cm/s (0–50, step 0.5)
- Selects: flow direction, material (grouped from `MATERIAL_OPTIONS`), gravity (0 g microgravity, 0.16 g Moon, 0.38 g Mars, 1 g Earth).
- Thickness (mm) is optional and display-only. It is **not** in the score; label it that way.
- **Done when:** every control updates the target, and the presets set O2 and pressure exactly.

### A3. Ranking, headline and hazard banner
- Files: `PyroVector.tsx`, new `web/src/components/HazardBanner.tsx`, `web/src/components/Headline.tsx`
- `const ranked = useMemo(() => rank(bundle.records, bundle.investigations, target), [...])`.
- **Headline:** the best match **in the active pillar** shows its BCMS as a large number, its coverage % (for example "Evidence covers 85% of the score weight: pressure not recorded") and its acronym and ref.
- **Hazard banner:** show it when `hazard(ranked, target)` returns non-null. Red for `hazard`, blue for `info`. List the reasons. For a hazard, also list the nearest bounding records from `bounds()`:
  - O2 and airflow for Flammability; O2 and pressure for Suppression.
  - For each: investigation acronym, ref, the value, Δ to the target, and the DOI link.
- **Done when:** ISS + SIBAL shows no banner and a headline of SAFFIRE-I at 84%; Lunar base + PMMA shows the hazard banner; choosing 0.16 g always shows the banner with LUCI and FM2.

### A4. Result cards (the core of Best Use of Data)
- File: new `web/src/components/ResultCard.tsx`. Render the top 8 of `ranked`, active-pillar results first, then the others under the heading "Other pillars (supporting evidence)".
- Each card shows:
  - Rank, investigation acronym and title, a pillar badge, a scale badge (full-scale / chamber), and BCMS %.
  - Five breakdown bars, one per component, in the order O2, material, airflow, pressure, pillar. Each bar shows its weight, its sub-score % (or a grey "not recorded" bar), its Δ with units, and its `basis`. Hovering shows NASA's raw cell and column (`raw`, `col`).
  - Record line: ref, table file name, row number, and material, plus `materialNote` if present. Write "record", not "test", when `investigation.recordsNotTests` is true.
  - Outcome fields from `record.outcome.fields`, verbatim, and only the non-empty ones.
  - Links: the DOI (`doiUrl`) and the PSI portal (`portalUrl`).
  - Under every card except the last: `whyAbove(card, nextCard).text` from `explain.ts`.
- **Guardrail:** never show a number that isn't in the record or the computed score. Never round a NASA raw value; show the raw cell.
- **Done when:** ISS + SIBAL shows SAFFIRE-I first, and its pressure bar is grey with "Not recorded in NASA's table".

### A5. Verdict card
- File: new `web/src/components/VerdictCard.tsx`
- Score all records for `allScored = bundle.records.map(r => scoreRecord(r, inv, target))`, memoised. Then call `buildVerdict(ranked, allScored, target.materialKey)`.
- If `available`, render each piece of evidence:
  - Kind badge: "NASA table" or "NASA written finding"
  - `facts` as a key/value table, verbatim
  - `reading` in bold when it's non-null
  - Source line: acronym, ref, table, row, DOI link
- If it's not available, show `message` verbatim.
- Card title: "Is 1 g screening conservative here? Cited NASA evidence only".
- **Done when:** Silicone shows SAFFIRE-II rows 2-1 to 2-4 with the 1 g vs microgravity reading, and Kapton shows the "No direct NASA… comparison" message.

### A6. Regime map
- Mount `RegimeMap` beside or under the headline. Pass `highlight = new Set(ranked.slice(0, 8).map(s => s.record.id))`.
- Fix any rendering issues you find. **Don't change** which points are plotted. They're real points only, and planned envelopes are excluded.
- **Done when:** Flammability shows the Saffire points in the main area and BASS-II in the left strip. Suppression shows FLEX and CFI-G coloured by outcome. The crosshair follows the sliders.

### A7. Method and limits footer
- File: new `web/src/components/Method.tsx`. Contents:
  - The BCMS formula and weights, copied from DECISIONS.md.
  - The status meanings.
  - Known gaps: no pressure for solid-material tests, no partial-gravity data, planned envelopes excluded.
  - Data source: NASA PSI, CC0, with the snapshot date `bundle.builtOn`.
  - A short "Use of SI" note pointing to SI disclosure.
- **Done when:** a judge can understand the score without reading the code.

### A8. Verify and deploy (by Sat 22:00)
- `npm test` and `npm run build` both pass.
- Manual checks:

| Scenario | Expected |
| --- | --- |
| ISS + SIBAL + 20 cm/s, Flammability | SAFFIRE-I ~84%, SAFFIRE-II ~83%, no banner |
| Lunar base + PMMA + 5 cm/s, Flammability | Hazard banner; best flammability match SAFFIRE-II ~60% |
| Exploration atmosphere + Nomex + 10 cm/s | Hazard banner |
| Lunar base + heptane + 0 cm/s, Suppression | FLEX ~78% first; no FLEX-2 in the ranking |
| Any setting + 0.16 g | Hazard banner mentions LUCI and FM2 |

- Push to GitHub. Pratt does this himself: `git remote add origin …` and `git push`.
- In Vercel: New Project → import the repo → set **Root Directory = `web`** → Deploy.
- Open the URL in a private window. Record the URL in STATUS.md.

---

## Phase B: depth and trust (Sun 09:00 to 15:00 freeze)

### B1. LLM "why" note (Claude Haiku), optional layer on A4
- New `web/src/app/api/why/route.ts` with a `POST` handler.
- **Input:** the two scored records (components, deltas, raw cells, refs).
- **Server-side only:** read `process.env.ANTHROPIC_API_KEY`, call the Anthropic Messages API with a Haiku model (check current model IDs in Anthropic's docs) and max 120 tokens.
- **Prompt:** "Using ONLY the numbers given, write one sentence explaining why record A ranks above record B…"
- **Firewall:** run `numericFirewall(text, allowedNumbers)`. If anything fails, return the deterministic `whyAbove` text instead and log the rejection.
- **Fallback:** any error, a missing key or a timeout over 4 s all return the deterministic text. The UI never waits on the LLM to rank.
- Pratt adds `ANTHROPIC_API_KEY` in Vercel → Project → Settings → Environment Variables. Never commit it.
- Tests: `numericFirewall` unit tests in `web/tests/explain.test.ts`.

### B2. Suppression polish
- Show FLEX-2 as a "Planned test envelope (context, not ranked)" panel on the Suppression tab, with its conditions as NASA lists them.
- Map legend and outcome copy reviewed against NASA wording.

### B3. Supporting text evidence (S1 channel 2)
- Do simple BM25 or keyword scoring in the client over each investigation's `objective + approach + impacts`, using the material name, pillar words and atmosphere words. **No new dependency** unless it's tiny.
- Panel: "NASA text that mentions your conditions". Show the investigation, a highlighted snippet and the DOI. This never affects BCMS.

### B4. Evaluation (S4)
- New `web/tests/eval.test.ts`, with about 10 engineer scenarios Pratt approves and the expected investigation(s) in the top 3.
- Report a top-3 hit rate.
- Show "Evaluated on N engineer scenarios: X/N expected NASA investigation in top 3" in the Method footer.

### B5. Shareable state
- Encode the target in URL query params so the demo and judges can open an exact scenario.

### B6. Performance and accessibility
- Trim the bundle: drop unused fields in `build_app_data.py`, keeping everything the UI cites.
- Keyboard-reachable controls, labels on sliders, contrast check, a mobile layout that stacks.

**Feature freeze: Sun 15:00.** After that, only bug fixes and copy changes.

### Could (only if Phase B is done before 13:00)
- Detection pillar (SAME / SAME-R: airflow + material only; no O2 or pressure)
- A natural-language bar that fills the sliders. It must show the parsed values for the user to confirm.
- An Earth spin-off tab on cards (P6)

---

## Phase C: story and submission (Sun 15:00 to 21:00)

Pratt leads this; agents help with copy and checks.

- **30-second demo video, following NASA's script:**
  - 0:00 team
  - 0:02 the challenge
  - 0:05 PyroVector and the tagline
  - 0:10 the ISS → Lunar base switch, where the hazard banner appears
  - 0:20 the future
- **Project page:** summary, detailed description, NASA data (each PSI investigation with its DOI), references (all libraries, the scaffold and the data), and the Use of SI field compiled from `agents/SI_LOG.md`.
- **Checks:** the live URL and the demo link both work in a private window with no login.
- **Submit by 21:00.** Resubmitting is allowed until 23:59.

---

## Prompt template for each Claude Code session

> Read AGENTS.md, agents/RULES.md, agents/DECISIONS.md, agents/BUILD_PLAN.md and web/AGENTS.md. Do task **A_** from BUILD_PLAN.md only. Don't change scoring semantics in web/src/lib/bcms.ts or verdict.ts. When done: run `cd web && npm test && npm run build`, tick the task in BUILD_PLAN.md, update agents/STATUS.md and agents/SI_LOG.md, and commit with a short imperative message with no AI attribution. If the task needs an undecided product choice, stop and ask.
